#!/bin/bash
input_file="$1"
output_file="$2"
./main.out "$input_file" "$output_file"