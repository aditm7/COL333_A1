#!/bin/bash
g++ -o ./main.out main.cpp SL.cpp algo.cpp -O3