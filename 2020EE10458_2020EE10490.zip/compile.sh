#!/bin/bash
g++ -o ./main.out main.cpp SL.cpp algo.cpp -std=c++17